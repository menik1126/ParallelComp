SPLIT_TOKEN = "=="
TEXT_BETWEEN_SHOTS = f"\n{SPLIT_TOKEN}\n"
N_TOKENS = 'n_tokens'
PROMPTS = 'prompts'
